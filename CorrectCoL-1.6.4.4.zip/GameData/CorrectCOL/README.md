﻿CorrectCoL - plugin for Kerbal Space Program by SQUAD.
Forum link:
http://forum.kerbalspaceprogram.com/index.php?/topic/160231-122-correctcol-stock-aerodynamics-design-aid-continued/

Lincensed under MIT.
Copyright (c) 2016 Boris-Barboris
